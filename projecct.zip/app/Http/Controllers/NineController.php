<?php

namespace App\Http\Controllers;

use App\Models\Nine;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class NineController extends Controller
{
    //
    public function index(){
        $data = Nine::all();
        return view('nine_users', ['users'=>$data]);
    }
   
    public function createUser(Request $request){
        $formFields = $request->validate([
            'name' => 'required|string|max:255',
            // 'email' => 'required|email|unique:nines',
            'email' => ['required','email', Rule::unique('nines', 'email')],
            'password' => 'required|min:3|max:15',
        ]);

        $formFields['password']=bcrypt($formFields['password']);

        if($formFields){
            $user = Nine::create($formFields);
            return back()->with('success','user created succesfully!');
        }
        
    }
}
