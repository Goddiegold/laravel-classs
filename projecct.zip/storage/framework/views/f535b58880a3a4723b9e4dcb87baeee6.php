<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Profile</title>
</head>
<body>
    <h1>Welcome <?php echo e(session('keyvalue')['name']); ?></h1>
    <a href="<?php echo e(route('logout')); ?>">Logout</a>
</body>
</html><?php /**PATH C:\MAMP\htdocs\project1\resources\views/profile.blade.php ENDPATH**/ ?>