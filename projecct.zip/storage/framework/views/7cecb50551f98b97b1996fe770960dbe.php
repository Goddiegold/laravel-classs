

<!-- <?php for($counter=1; $counter<10; $counter++): ?>
<h1><?php echo e($counter); ?></h1>
<?php endfor; ?> -->

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2><?php echo e($name); ?></h2>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<form action="" method="get">
    <input type="text" placeholder="Email"><br/>
    <input type="text" placeholder="Password"><br/>
    <button>Submit</button>
</form><?php /**PATH C:\MAMP\htdocs\project1\resources\views/home.blade.php ENDPATH**/ ?>