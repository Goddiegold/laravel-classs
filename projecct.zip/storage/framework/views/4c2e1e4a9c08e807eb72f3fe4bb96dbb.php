<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page 1</title>
</head>
<body>
    <?php echo $__env->make('page1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Page 2</h1>
    <a href="page-1">URL 1</a>
    <a href="page-2">URL 2</a>
    <a href="page-3">URL 3</a>
    <h2>
        FROM : <?php echo e(URL::previous()); ?>

</h2>
<h2>
    my current url is : <?php echo e(URL::current()); ?>

</h2>
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\project1\resources\views/page2.blade.php ENDPATH**/ ?>