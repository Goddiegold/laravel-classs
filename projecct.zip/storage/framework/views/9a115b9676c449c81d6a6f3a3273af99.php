<?php
echo "Hello world";
?>

<h1>my result is <?php echo e(50+50); ?></h1><?php /**PATH C:\MAMP\htdocs\project1\resources\views/hello.blade.php ENDPATH**/ ?>