<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page 1</title>
</head>
<body>
<h1>Page 1</h1>
<?php if (isset($component)) { $__componentOriginalb30baa86737d521c4b5270cf90cd1197 = $component; } ?>
<?php $component = App\View\Components\Headercomponent::resolve(['title' => 'Header Component from Page 1, Temi is a goat, from Ondo'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('headercomponent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Headercomponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb30baa86737d521c4b5270cf90cd1197)): ?>
<?php $component = $__componentOriginalb30baa86737d521c4b5270cf90cd1197; ?>
<?php unset($__componentOriginalb30baa86737d521c4b5270cf90cd1197); ?>
<?php endif; ?>
<a href="page-1">URL 1</a>
    <a href="page-2">URL 2</a>
    <a href="page-3">URL 3</a>
    <h2>
        FROM : <?php echo e(URL::previous()); ?>

</h2>
<h2>
    my current url is : <?php echo e(URL::current()); ?>

</h2>
<script>
        console.log("Hello world");
        const people = [];
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            people.push("<?php echo $person; ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        console.log(people);
    </script>

</body>
</html>
<?php /**PATH C:\MAMP\htdocs\project1\resources\views/page1.blade.php ENDPATH**/ ?>