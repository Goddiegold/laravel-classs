<?php
echo "Contact Page";
?>

<h1>Current Page <?php echo e($pageName); ?></h1><?php /**PATH C:\MAMP\htdocs\project1\resources\views/contact.blade.php ENDPATH**/ ?>