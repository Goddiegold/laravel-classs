<div>
    <!-- The biggest battle is the war against ignorance. - Mustafa Kemal Atatürk -->
    <h1 class="text-center">Header Component</h1><br/><hr />
    <h1><?php echo e($title); ?></h1>
</div><?php /**PATH C:\MAMP\htdocs\project1\resources\views/components/headercomponent.blade.php ENDPATH**/ ?>