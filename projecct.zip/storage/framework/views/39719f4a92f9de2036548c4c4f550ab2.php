<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>No Access</title>
</head>
<body>
    <h1>You should be more than 18yrs</h1>
</body>
</html><?php /**PATH C:\MAMP\htdocs\project1\resources\views/noaccess.blade.php ENDPATH**/ ?>