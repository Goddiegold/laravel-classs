<div>
    <!-- The biggest battle is the war against ignorance. - Mustafa Kemal Atatürk -->
    <h1 class="text-center">Header Component</h1><br/><hr />
    <h1>{{ $title }}</h1>
</div>