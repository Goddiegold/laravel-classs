<?php
echo "Hello world";
?>

<h1>my result is {{50+50}}</h1>