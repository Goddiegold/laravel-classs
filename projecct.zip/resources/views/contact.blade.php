<?php
echo "Contact Page";
?>

<h1>Current Page {{$pageName}}</h1>