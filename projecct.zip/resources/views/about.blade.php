<?php
echo "About Page";
?>

<h1>Current Page {{$pageName}}</h1>