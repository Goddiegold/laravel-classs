<?php
echo "Service Page";
?>

<h1>Current Page {{$pageName}}</h1>